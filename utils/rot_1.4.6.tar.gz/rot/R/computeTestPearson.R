"computeTestPearson" <-
function(inData, outData, testLevel = 0.95) {
  # Reusing computeTestPartialPearson on the whole dataset.
  computeTestPartialPearson(inData, outData, selection = 1 : dim(inData)[1], testLevel)
}

