"computeTestSpearman" <-
function(inData, outData, testLevel = 0.95) {
  # Reusing computeTestPartialSpearman on the whole dataset.
  computeTestPartialSpearman(inData, outData, selection = 1 : dim(inData)[1], testLevel)
}

