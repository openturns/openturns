"computeTestTwoSampleChiSquared" <-
function(numericalSample1, numericalSample2, testLevel = 0.95) {

  # Direct application of chisq.test ('stats' package). 
  testChiSquared <- chisq.test(numericalSample1, numericalSample2)    
  
  testResult <- ifelse(testChiSquared$p.value > 1 - testLevel, 1, 0)
  return(list(test = "TwoSampleChiSquared",
              testResult = testResult,
              threshold = 1 - testLevel,
              pValue = testChiSquared$p.value))
}

